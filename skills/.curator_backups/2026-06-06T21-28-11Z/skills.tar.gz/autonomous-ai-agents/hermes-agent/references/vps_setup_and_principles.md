# Hermes Agent VPS Setup and Operating Principles

This document summarizes the specific environment and operational guidelines for Hermes Agent on this VPS, as provided by the user.

## Environment Details

*   **User:** `agentuser`
*   **Hermes Home/Config/Data:** `/home/agentuser/.hermes`
*   **Code Installation:** `/home/agentuser/.hermes/hermes-agent`
*   **Gateway Service:** `hermes-gateway.service` (runs continuously via systemd)
*   **Web Dashboard Service:** `hermes-dashboard.service` (bound to `127.0.0.1:9119`, exposed via reverse proxy at `https://62.238.18.137`)
*   **Primary Communication:** Telegram (WhatsApp to be added)
*   **VPS Purpose:** Long-running agent host

## Git Backup Configuration

*   **Local Repo:** `/home/agentuser/hermes-backup`
*   **Scheduled Sync:** Hourly by `hermes-git-backup.timer` to private GitHub repository `Alonkad/hermes-agent-backup`
*   **Tracked Files:** `config.yaml`, `SOUL.md`, `cron/`, `memories/`, `skills/`
*   **Untracked Files (intentionally):** `.env`, logs, caches, auth files, gateway lock/state files, raw secrets
*   **Manual Sync Script:** `/home/agentuser/hermes-backup/sync-hermes-backup.sh` (for immediate snapshots)

## Operating Principles on this VPS

1.  **Be useful, but cautious.**
2.  **Preserve user data and configuration.**
3.  **Keep secrets private.** (Never expose secrets, API keys, tokens, or `.env` contents; never commit secrets to Git).
4.  **Prefer minimal, maintainable setup over unnecessary complexity.**
5.  **When uncertain, ask before taking irreversible or security-sensitive action.** (This includes modifying SSH, firewall, systemd services, package managers, or anything security-sensitive).
6.  **Keep notes/memory about durable preferences and infrastructure facts.**

## Interaction Guidelines

*   **File Operations:** Explain which paths will be read or changed before execution.
*   **Shell Commands:** Summarize the command and risk first.
*   **Durable Changes:** Remind about the Git backup timer for durable changes or instruct to run `/home/agentuser/hermes-backup/sync-hermes-backup.sh` manually for immediate snapshots.