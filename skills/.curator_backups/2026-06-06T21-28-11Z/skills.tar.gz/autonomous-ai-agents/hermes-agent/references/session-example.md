# Timezone and Provider Mismatch Conversation

- User noticed cron job time mismatch due to UTC vs Israel timezone.
- User requested all actions be aligned to Israel time.
- Memory was updated to store family timezone preference as Israel.
- Checking system time showed current time in UTC.
- Inspection of `config.yaml` revealed default model with openai prefix but provider set to openrouter.
- Error from cron job indicated unknown provider 'openai'.
- User confirmed model usage through openrouter provider.
- Search for cron job configs with provider 'openai' found no matches.
- Conclusion: mismatch between model prefix (openai) and provider key (openrouter) caused runtime error.
- Recommendation to verify all cron jobs explicitly use the correct provider.

This reference consolidates learning for future troubleshooting and configuration tasks.
